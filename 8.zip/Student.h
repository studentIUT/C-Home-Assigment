/*
lab asigment #8
ID: U2310240
Name: Sedelkov Andrey
Date: 19.04.2024
file: Student.h
*/


// Include the string libraries
#include <iostream>
#include <string>
using namespace std; // Use the standard namespace

template<class T, class T1, class T2> // Define a template class

class Student { // Define the Student class
private:
	T IDNumber; // Declare a private member variables
	T1 Age;
	T2 Gender;
	string Name;
public:
	Student() { //defolt constructor
		IDNumber = 0;
		Name = "UNKNOWN";
		Age = 0;
		Gender = 'U';
	}

	Student(T ID, string name, T age, T gend) { //parameterized constructor
	IDNumber = ID;
	Name = name;
	Age = age;
	Gender = gend;
	}
	void displayDetails() { //output function 
		cout << "Name: " << Name << endl;
		cout << "ID Number: " << IDNumber << endl;
		cout << "Age: " << Age << endl;
		cout << "Gender: " << Gender << endl;
	};
};
