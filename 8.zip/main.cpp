/*
lab asigment #8
ID: U2310240
Name: Sedelkov Andrey
Date: 19.04.2024
file: main.cpp
*/


#include "Student.h" //using header file Student.h


int main() { //main function

	Student<int, float, char> s(2310240, "Andrey Sedelkov", 18, 'M'), m; //initializing class objects
	cout << "Defolt Student info: " << endl;  m.displayDetails(); //output defolt parametrs of constructor 
	cout << "\n\nParameterized  Student info: " << endl; s.displayDetails(); //output parameterized parametrs of constructor
	return 0; //exit from a program
}