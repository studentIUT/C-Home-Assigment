/*
U2310240
Sedelkov Andrey
15.03.2024*/

using namespace std;
int mlt = 3;


//Account class definition
class AccountArray {
    const int MAX_SIZE = 10;
    struct Account {
        int AccountNumber;
        double BalanceAmount;
        Account() : AccountNumber(0.0), BalanceAmount(0.0) {}
        Account(int accNumber, double balance) : AccountNumber(accNumber), BalanceAmount(balance) {}

        bool operator==(const Account& other) const
        {
            return false;
        }
    };

    Account* accounts;
    int size;
public:
    //Default Constractor for the array
    AccountArray() : size(0) {
        accounts = new Account[MAX_SIZE];
    }
    //Copy constructor
    AccountArray(const AccountArray& other) : size(other.size) {
        accounts = new Account[MAX_SIZE];
        for (int i = 0; i < size; ++i) {
            accounts[i] = other.accounts[i];
        }
    }
//destructor
    ~AccountArray() {
        delete[] accounts;
    }

    void addAccount(int accNumber, double balance) {
        if (size < MAX_SIZE) {
            accounts[size] = Account(accNumber, balance);
            size++;
        } else {
            cout << "Cannot add more."<<endl;
            
        }
    }

    //Definition of * operator
    AccountArray operator*(int multiplier) {
        AccountArray result;
        for (int i = 0; i < size; ++i) {
            result.accounts[i] = Account(accounts[i].AccountNumber, accounts[i].BalanceAmount * multiplier);
            result.size++;
            multiplier++;
        }
        return result;
    }
    AccountArray operator*(double multiplier) {
        AccountArray result;
        for (int i = 0; i < size; ++i) {
            result.accounts[i] = Account(accounts[i].AccountNumber, accounts[i].BalanceAmount * multiplier);
            multiplier *= 2;
            result.size++;
            
        }
        return result;
    }
//Definitions of friend functions
    friend ostream& operator<(ostream& os, const AccountArray& arr);
    friend ostream& operator<<(ostream& os, const AccountArray& arr);
    friend istream& operator>>(istream& is, AccountArray& arr);
};

//Full definition of output of initial input 
ostream& operator<(ostream& os, const AccountArray& arr) {
    for (int i = 0; i < arr.size; ++i) {
        os << "Account " << i + 1 << ":\n";
        os << "  Account Number: " << arr.accounts[i].AccountNumber << "\n";
        os << "  Balance Amount: " << arr.accounts[i].BalanceAmount << "$" << endl;
    }
    return os;
}

//Full definition of output after multiplayed function 
ostream& operator<<(ostream& os, const AccountArray& arr) {
    for (int i = 0; i < arr.size; ++i) {
        os << "Account " << i + 1 << ":\n";
        os << "  Account Number: " << arr.accounts[i].AccountNumber << "\n";
        os << "  Balance Amount: " << arr.accounts[i].BalanceAmount << "$" << " (multiplied by " << i+3 << ")" << endl;
    }
    return os;
}

//Full definition of output after multiplayed function 


istream& operator>>(istream& one, AccountArray& arr) {
    int Num;
    double balance;
    cout << "Enter Account Number: ";
    one >> Num;
    cout << "Enter Balance Amount: ";
    one >> balance;
    arr.addAccount(Num, balance);
    return one;
}
