/*
U2310240
Sedelkov Andrey
15.03.2024*/

#include <iostream>
#include "Account.h"
using namespace std;

int main() {
    int num;
    AccountArray accountArray;
    cout << "enter number of accounts (MAX 10) : " ; cin >> num;
        //Input accounts to the array
        for (int i = 0; i < num; i++) {
            cout << "Enter details for Account " << i + 1 <<endl;
            cin >> accountArray;
        }
    
       
        system("cls");

        // Display the original array
        cout << "*******************************************\n\nOriginal Account Array:\n"<< endl;
        cout < accountArray;
       
        
    
        // Display the multiplied array by int
        cout << "\n*******************************************\n\nArray after miltiplied on int\n" << accountArray * 3;// Multiply
        // Display the multiplied array by double
        cout << "\n*******************************************\n\nArray after miltiplied on double\n" < accountArray * 0.1;// Multiply

    return 0;
}
