/*
U2310240
Sedelkov Andrey
24/03/2024
*/


#include "Student.h"


//defolt
Student::Student() {
    id = 0;
    name = "";
    school = 0;
    groupnumber = 0;
}

//parametrized constructors
void Student::setID(int id) {
    this->id = id;
}

void Student::setName(const string &name) {
    this->name = name;
}

void Student::setSchool(int school) {
    this->school = school;
}

void Student::setGroupNumber(int group) {
    this->groupnumber = group;
}

int Student::getID() {
    return id;
}

string Student::getName() {
    return name;
}

int Student::getSchool() {
    return school;
}

int Student::getGroupNumber() {
    return groupnumber;
}

void Student::display() {
    cout << "\n\t*****OUTPUT*****\n" << endl;
    cout << "ID of student U" << getID() << endl;
    cout << "Name of student: " << getName() << endl;
    cout << "NUM of school: " << getSchool() << endl;
    cout << "Enter group number: " << getGroupNumber() << endl;

}

