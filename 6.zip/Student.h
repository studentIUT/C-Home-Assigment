/*
U2310240
Sedelkov Andrey
24/03/2024
*/


#include <string>
#include <iostream>
using namespace std;
//definition of the Student class
class Student {
    //private data
private:
    int id;
    string name;
    int school;
    int groupnumber;
public:
    //defolt constructor
    Student();
    //creating set and get functions
    void setID(int id);
    void setName(const string &name);
    void setSchool(int school);
    void setGroupNumber(int group);
    int getID();
    string getName();
    int getSchool();
    int getGroupNumber();
    void display();
};

