/*
U2310240
Sedelkov Andrey
24/03/2024
*/



#include "Test.h"


//defolt
Test::Test() {
    Physics = 0;
    OOP = 0;
    English = 0;
}
//parametrized constructors
void Test::setPhysics(int score) {
    Physics = score;
}

void Test::setOOP(int score) {
    OOP = score;
}

void Test::setEnglish(int score) {
    English = score;
}

int Test::getPhysics() {
    return Physics;
}

int Test::getOOP() {
    return OOP;
}

int Test::getEnglish() {
    return English;
}
