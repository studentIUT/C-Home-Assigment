/*
U2310240
Sedelkov Andrey
24/03/2024
*/


#include "Test.h"


//inheriting of Test class
class Result : public Test {
private:
    int Total;
    float GPI;
public:
    //defolt constructor
    Result();
    //creating functions
    void calculateTotal();
    void calculateGPI();
    //Creating Display
    void display();
};

