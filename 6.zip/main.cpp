/*
U2310240
Sedelkov Andrey
24/03/2024
*/


#include "Result.h"
//defolt
Result::Result() {
    Total = 0;
    GPI = 0.0f;
}

//functions of result class
void Result::calculateTotal() {
    Total = Physics + OOP + English;
}

void Result::calculateGPI() {
    GPI = Total / 3.0f;
}

void Result::display() {
    cout << "Total Marks: " << Total <<endl;
    cout << "GPI: " << GPI <<endl;
}



int main() {
    //creation of the object and variables
    Student StudentInfo;
    Result studentResult;
    int id,school, groupnumber, ph, oop, en;
    string name;
    //input from user
    cout << "Enter ID of student U"; cin >> id;
    cout << "Enter name of student: "; cin >> name;
    cout << "Enter NUM of school: "; cin >> school;
    cout << "Enter group number: "; cin >> groupnumber;
    cout << "\n\t****************\n" << endl;
    cout << "Enter mark Physics: "; cin >> ph;
    cout << "Enter mark OOP: "; cin >> oop;
    cout << "Enter mark English: "; cin >> en;

    //student class fenctions
    StudentInfo.setID(id);
    StudentInfo.setName(name);
    StudentInfo.setSchool(school);
    StudentInfo.setGroupNumber(groupnumber);
    //result class functions
    studentResult.setPhysics(ph);
    studentResult.setOOP(oop);
    studentResult.setEnglish(en);
    studentResult.calculateTotal();
    studentResult.calculateGPI();
    //display
    StudentInfo.display();
    studentResult.display();
    return 0;
}


