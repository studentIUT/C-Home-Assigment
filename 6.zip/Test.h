/*
U2310240
Sedelkov Andrey
24/03/2024
*/


#include "Student.h"
//inheriting of Student class
class Test : public Student {
public:
    int Physics;
    int OOP;
    int English;

    Test();
    //creating set and get functions 
    void setPhysics(int score);
    void setOOP(int score);
    void setEnglish(int score);
    int getPhysics();
    int getOOP();
    int getEnglish();
};

