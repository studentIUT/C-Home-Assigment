//including preprocessor
#include <iostream>
#include <string>
//using namespace
using namespace std;


//begin of class
class Manage {

	//private data of class
private:
	int propertyId;
	string propertyName;
	string propertyType;
	int propertyValue;
	string propertyAddress;
	int propertyBedrooms;

	//public part of class
public:
	Manage() {
		cout << "defolt construction" << endl;
		propertyId = 0;
		propertyName = "Name";
		propertyType = "Type";
		propertyValue = 0;
		propertyAddress = "Address";
		propertyBedrooms = 0;
	}
	Manage(int Id, string Name, string Type, int Value, string Address, int Bedrooms) {
		propertyId = Id;
		propertyName = Name;
		propertyType = Type;
		propertyValue = Value;
		propertyAddress = Address;
		propertyBedrooms = Bedrooms;
	}
	void display() {
		cout << "Id: " << propertyId << endl;
		cout << "Name: " << propertyName << endl;
		cout << "Type: " << propertyType << endl;
		cout << "Value: " << propertyValue << "$" << endl;
		cout << "Adress: " << propertyAddress << endl;
		cout << "Bedrooms: " << propertyBedrooms << endl;
		PropertyTax();
	}
	void PropertyTax() {
		double tax = 0;
		tax += propertyValue * 0.2;
		cout << "Tax: " << tax << "$\n" << endl;
	}
	~Manage() {
		cout << "destroyed" << endl;
	};

}; //end of class