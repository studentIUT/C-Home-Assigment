/*
ID: U2310240
Name: Sedelkov Andrey
Date: 23.02.2024
*/
#include "Property.h"

int main() {
	//our variables and declarate mng of type manage 
	int num;
	
	system("cls");								 //clear terminal from previous output
	do
	{
		Manage mge;
		mge.display();
		system("pause"); system("cls");								 //clear terminal from previous output
		Manage mng(2310240, "Andrey Sedelkov", "Flat", 500, "Tashkent", 2); //using construction
		cout << "**********OUTPUT**********\n" << endl; //output of result	
		mng.display();

		system("pause"); system("cls");//pause working
		cout << "Which program would you like to use?\n1 - Real Estate Management System\n0 - Exit\nEnter number: "; cin >> num;
	} while (num != 0);
}