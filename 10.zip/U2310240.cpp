/*
 U2310240
 Andrey Sedelkov
 03.05.2024
 */

#include <iostream>
#include <fstream>
#include <string>
using namespace std; // Import standard library namespace

const int MAX_RECORDS = 100; // Maximum number of records

class Person {
private:
    string Name;
    string PhoneNumber;

public:
    // Constructors
    Person()
    {
        Name = "";
        PhoneNumber = "";
    }
    Person(const string& name, const string& phoneNumber)
    {
        Name = name;
        PhoneNumber = phoneNumber;
    }

    // Accessors
    string getName() const
    {
        return Name;
    }
    string getPhoneNumber() const
    {
        return PhoneNumber;
    }

    // Mutators
    void setName(const string& name)
    {
        Name = name;
    }
    void setPhoneNumber(const string& phoneNumber)
    {
        PhoneNumber = phoneNumber;
    }

    // File I/O
    void saveToFile(ofstream& file) const
    {
        file << Name << " " << PhoneNumber << endl;
    }
    void readFromFile(ifstream& file)
    {
        file >> Name >> PhoneNumber;
    }
};


// Function to read all records from file into an array of Persons
int readRecordsFromFile(Person persons[], int& count) {
    ifstream file("Person.dat");
    if (file.is_open()) {
        count = 0;
        while (count < MAX_RECORDS && !file.eof()) {
            Person p;
            p.readFromFile(file);
            if (!p.getName().empty() && !p.getPhoneNumber().empty()) {
                persons[count++] = p;
            }
        }
        file.close();
    }
    return count;
}

// Function to display all records
void displayRecords(const Person persons[], int count) {
    for (int i = 0; i < count; ++i) {
        cout << "Name: " << persons[i].getName() << ", Phone Number: " << persons[i].getPhoneNumber() << endl;
    }
}

// Function to find phone number by name
void findPhoneNumberByName(const Person persons[], int count) {
    string name;
    cout << "Enter the name to find: ";
    cin >> name;
    for (int i = 0; i < count; ++i) {
        if (persons[i].getName() == name) {
            cout << "Phone Number: " << persons[i].getPhoneNumber() << endl;
            return;
        }
    }
    cout << "Name not found." << endl;
}

// Function to find name by phone number
void findNameByPhoneNumber(const Person persons[], int count) {
    string phoneNumber;
    cout << "Enter the phone number to find: ";
    cin >> phoneNumber;
    for (int i = 0; i < count; ++i) {
        if (persons[i].getPhoneNumber() == phoneNumber) {
            cout << "Name: " << persons[i].getName() << endl;
            return;
        }
    }
    cout << "Phone number not found." << endl;
}

// Function to delete a record by name
void deleteRecordByName(Person persons[], int& count) {
    string nameToDelete;
    cout << "Enter the name to delete: ";
    cin >> nameToDelete;
    for (int i = 0; i < count; ++i) {
        if (persons[i].getName() == nameToDelete) {
            for (int j = i; j < count - 1; ++j) {
                persons[j] = persons[j + 1];
            }
            --count;
            cout << "Record deleted." << endl;
            return;
        }
    }
    cout << "Name not found. No record deleted." << endl;
}

// Function to add a record at a specific position
void addRecord(Person persons[], int& count) {
    if (count < MAX_RECORDS) {
        string name, phoneNumber;
        cout << "Enter name and phone number to add: ";
        cin >> name >> phoneNumber;
        Person p(name, phoneNumber);
        int position;
        cout << "Enter position to add (1-" << count + 1 << "): ";
        cin >> position;
        if (position < 1 || position > count + 1) {
            cout << "Invalid position. Record not added." << endl;
            return;
        }
        for (int i = count; i >= position; --i) {
            persons[i] = persons[i - 1];
        }
        persons[position - 1] = p;
        ++count;
        cout << "Record added." << endl;
    }
    else {
        cout << "Cannot add more records. Storage full." << endl;
    }
}


int main() {
    Person persons[MAX_RECORDS];
    int count = 0;
    readRecordsFromFile(persons, count);
    int m=0;
    int choice;
    do {
        if (m != 0) {
            system("pause");
            system("cls");
            
        }
        m=1;
        cout << "Menu:"<<endl;
        cout << "1. Find telephone number of a person" << endl;
        cout << "2. Find name if telephone number is known" << endl;
        cout << "3. Delete a record" << endl;
        cout << "4. Add a record" << endl;
        cout << "5. Display records" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            findPhoneNumberByName(persons, count);
            break;
        case 2:
            findNameByPhoneNumber(persons, count);
            break;
        case 3:
            deleteRecordByName(persons, count);
            break;
        case 4:
            addRecord(persons, count);
            break;
        case 5:
            displayRecords(persons, count);
            break;
        case 0:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice. Try again." << endl;
        }
    } while (choice != 0);

    // Save updated records back to file
    ofstream outFile("Person.dat");
    if (outFile.is_open()) {
        for (int i = 0; i < count; ++i) {
            persons[i].saveToFile(outFile);
        }
        outFile.close();
    }

    return 0;
}