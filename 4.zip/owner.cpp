/*
Sedelkov Andrey
U2310240
09.03.2024
*/


#include "Owner.h" //include header file

int main() {
    int n = 1;
    do {
        system("cls"); //clear console

        // Creating Property objects
        Property property1(156581, "Luxury Villa", "Residential", 500000);
        Property property2(1002, "Apartment", "Residential", 70000);

        //operators overloading
        if (property1 == property2) {
            cout << "The properties have the same ID." << endl;
        }
        else {
            cout << "The properties have different IDs." << endl;
        }

        Property property3 = property1 + property2; //cleate operator overloading
        cout << "After combining properties: " << property3.getPropertyValue() << ", Value:" << property3.getPropertyValue() << endl;

        Property property4 = property1 - property2;
        cout << "After subtracting properties: " << property4.getPropertyValue() << ", Value:" << property4.getPropertyValue() << endl;

        Property property5;
        cin >> property5;
        cout << property5;
        cout << "\nIf tou would like exit from app press 0: "; cin >> n;
    } while (n!=0);

    return 0;
}
