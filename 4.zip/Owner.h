/*
Sedelkov Andrey
U2310240
09.03.2024
*/


#include <iostream>
using namespace std;

//Declaration of Class
class Property
{
    //private data
    int propertyId;
    string propertyName;
    string propertyType;
    int propertyValue;

    //public methods
public:

    //Default Constructor
    Property() {
        propertyId = 0;
        propertyName = "default";
        propertyType = "default";
        propertyValue = 0.0;
    }

    //Parametrized Constructor
    Property(int ID, string name, string type, double value) {
        propertyId = ID;
        propertyName = name;
        propertyType = type;
        propertyValue = value;
    }

    //Get function accessor
    int getPropertyValue()
    {
        return propertyValue;
    }

    //Operator overloadings
    bool operator==(const Property& prop) {
        return this->propertyId == prop.propertyId;
    }

    Property operator+(const Property& prop) {
        Property plus;
        plus.propertyId = this->propertyId + prop.propertyId;
        plus.propertyValue = this->propertyValue + prop.propertyValue;
        return plus;
    }

    Property operator-(const Property& prop) {
        Property minus;
        minus.propertyId = this->propertyId - prop.propertyId;
        minus.propertyValue = this->propertyValue - prop.propertyValue;
        return minus;
    }

    friend void operator<<(ostream& output, Property& prop);
    friend void operator>>(istream& input, Property& prop);
    //Distructor
    ~Property() {
    }
};
//Definition of the friend function

void operator >> (istream& input, Property& prop)
{
    cout << "********************************************\nProperty ID: "; input >> prop.propertyId;
    cout << "Property Name: "; input >> prop.propertyName;
    cout << "Property Type: "; input >> prop.propertyType;
    cout << "Property Value: "; input >> prop.propertyValue;
}
void operator << (ostream& output, Property& prop)
{
    
    output << "********************************************\nProperty 5: \nProperty ID: " << prop.propertyId << endl;
    output << "Property Name: " << prop.propertyName << endl;
    output << "Property Type: " << prop.propertyType << endl;
    output << "Property Value: " << prop.propertyValue << endl;
}



