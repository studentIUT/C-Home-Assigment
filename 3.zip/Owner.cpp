/*
Sedelkov Andrey
U2310240
01.03.2024
*/

#include "Owner.h"


Owner::Owner() {}

void Owner::setOwnerID(int ID) {
    this->ID = ID;
}
int Owner::getOwnerID() {
    return ID;
}
void Owner::setOwnerName(string name) {
    Name = name;
}
string Owner::getOwnerName() {
    return Name;
}