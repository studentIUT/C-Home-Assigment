/*
Sedelkov Andrey
U2310240
01.03.2024
*/

#include <iostream>
#include <string>
using namespace std;


class Owner {
public:
    int ID;
    string Name;

    Owner();
    Owner(int ID, string name);

    void setOwnerID(int ID);
    int getOwnerID();
    void setOwnerName(string name);
    string getOwnerName();

};
