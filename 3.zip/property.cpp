/*
Sedelkov Andrey
U2310240
01.03.2024
*/

#include "property.h"
using namespace std;

Property::Property() {}

void Property::setPropertyID(int ID) {
    this->ID = ID;
}

int Property::getPropertyID() {
    return ID;
}

void Property::setPropertyName(string name) {
    this->Name = name;
}

string Property::getPropertyName() {
    return Name;
    
}

Owner Property::getOwner() {
    return owner;
}

void Property::setOwnerDetails(int ID, string name) {
    owner.setOwnerID(ID);
    owner.setOwnerName(name);
}


void Display(Property* prop, int size) {
    for (int i = 0; i < size; i++)
    {
        cout << "Output: " << i + 1 <<endl;
        cout << "\tProperty with ID: " << prop[i].ID << "\n\tname: " << prop[i].Name << "\n\towner ID: " << prop[i].owner.ID << "\n\tname: "<< prop[i].owner.Name << endl << endl;
        
    }
}
int main() {
    int a=1; 
    system("cls");
    if (a!=0)
    {
        int size;
        cout << "Enter number: "; cin >> size;
        Property* arr = new Property[size];
        for (int i = 0; i < size; i++) {
            Property mng;
            cout << "Property #" << i + 1 << endl;
            cout << "\tID: "; cin >> mng.ID;
            cout << "\tName: "; cin >> mng.Name;
            cout << "Owner #" << i + 1 << endl;
            cout << "\tID: "; cin >> mng.owner.ID;
            cout << "\tName: "; cin >> mng.owner.Name;
            arr[i] = mng;
            
        }
        Display(arr, size);
        delete[] arr;
        cout << "if you would like to exit press 0 "; cin >> a;
    }
    
    return 0;
}