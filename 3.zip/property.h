/*
Sedelkov Andrey
U2310240
01.03.2024
*/

#include "Owner.h"

class Property {

public:
    int ID;
    string Name;
    Owner owner;

    Property();
    Property(int ID, string name, Owner owner);

    void setPropertyID(int ID);
    int getPropertyID();
    void setPropertyName(string name);
    string getPropertyName();
    void setOwnerDetails(int ID, string name);
    Owner getOwner();
};


